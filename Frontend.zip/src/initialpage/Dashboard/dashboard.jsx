import React from 'react'

const Dashboard = () => {
    console.log('asasa:::');
    return (
        <div style={{ height: '100%'}}>
            This is Our Dashboard
        </div>
    )
}

export default Dashboard
