/**
 * Crm Routes
 */
/* eslint-disable */
import React from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import ManagerDashboard from './Manager/managerdashboard';
import Workshope from './ManagerWorkshop/workshope';
import EmployeeDashboard from './Employee/employeedashboard';
import CeoDashboard from './Ceo/ceodashboard';
import ApproveRequest from '../../HR/Sales/approverequest';
//  import ApproveRequest1 from '../../HR/Sales/approverequest1';

import { Divider } from 'material-ui';
import Projects from './Project/projects';
import Tasks from './tasks/tasks';
import Feedback from './tasks/Feedback';
import CompletedTask from './tasks/taskboard';
import ProjectList from './Project/projectlist';
import EmployeeWorkshop from './Employee/EmployeeWorkshop';
import EmployeeTasks from './Employee/Tasks/employeeTasks'

// const userType = localStorasssge.getItem('u')


const DashboardRoute = ({ match }) => (
      // console.log('awais testing', `${match.url}/dashboard`);
      <Switch>
    
      <Route  path={`${match.url}/dashboard/manager`} component={ManagerDashboard} />
      <Route  path={`${match.url}/manager/workshope`} component={Workshope} />
      <Route  path={`${match.url}/dashboard/employee`} component={EmployeeDashboard} />
      <Route  path={`${match.url}/dashboard/ceo`} component={CeoDashboard} />
      <Route  path={`${match.url}/approve-request`} component={ApproveRequest} />
      <Route  path={`${match.url}/projects`} component={Projects} />
      <Route  path={`${match.url}/tasks`} component={Tasks} />
      <Route  path={`${match.url}/completedTask`} component={CompletedTask} />
      <Route  path={`${match.url}/projectlist`} component={ProjectList} />
      <Route  path={`${match.url}/employeeworkshop`} component={EmployeeWorkshop} />
      <Route  path={`${match.url}/employeetasks`} component={EmployeeTasks} />

      <Route  path={`${match.url}/feedbacks`} component={Feedback} />
          
       
   </Switch>


)




   
  


export default DashboardRoute;
