/**
 * TermsCondition Page
 */
 import React, { Component, useEffect, useState } from "react";
 import { Helmet } from "react-helmet";
 import axios, { CancelTokenSource } from "axios";


 import Button from "@material-ui/core/Button";
 import Dialog from "@material-ui/core/Dialog";
 import DialogActions from "@material-ui/core/DialogActions";
 import DialogContent from "@material-ui/core/DialogContent";
 import DialogContentText from "@material-ui/core/DialogContentText";
 import DialogTitle from "@material-ui/core/DialogTitle";
 
 const Conference = () => {

   // const ManagerProfileCreateApi = () => {
   //   const response = ManagerProfileCreate(
   //     5,
   //     first_name,
   //     last_name,
   //     dob,
   //     postalCode,
   //     gender,
   //     address,
   //     country,
   //     cancelTokenSource.token
   //   );
 
   //   console.log(response, "awaisssssss");
   //   // setOpenCreataeProfile(true);
   // };
 

   return (
     <React.Fragment>
        conference
     </React.Fragment>
   );
 };
 
 export default Conference;
 