import CustomerProfile from "../../models/customer/CustomerProfile";

export default interface CustomerProfileRes {
    customer: CustomerProfile;
}