import RistAssessmentReportOverAllRes from "../../models/customer/RistAssessmentReportOverAllRes";

export default interface RistAssessmentReportOverAllStatusRes {
    overAllRisk: RistAssessmentReportOverAllRes;
}