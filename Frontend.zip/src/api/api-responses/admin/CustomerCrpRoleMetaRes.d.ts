import CustomerCrpRoleMeta from "../../models/customer/CustomerCrpRoleMetaType"

export default interface CustomerCrpRoleMetaRes {
    crp_roles_meta: Array<CustomerCrpRoleMeta>;
}