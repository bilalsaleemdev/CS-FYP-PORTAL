import CustomerCrpCorporateProfile from "../../models/customer/CustomerCrpCorporateProfile";

export default interface CustomerCrpsCorporateProfileRes {
    crp: CustomerCrpCorporateProfile;
}