
export default interface RistAssessmentStatusRes {
    riskTab: boolean;
}