import CRPIndividualDocument from "../../models/customer/CRPIndividualDocument"

export default interface CRPIndividualDocumentRes {
    crp_documents: Array<CRPIndividualDocument>;
}
