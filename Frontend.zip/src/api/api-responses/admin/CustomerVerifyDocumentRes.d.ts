import CustomerVerifyDocument from "../../models/customer/CustomerVerifyDocument"

export default interface CustomerVerifyDocumentRes {
    restricted_list: CustomerVerifyDocument;
}