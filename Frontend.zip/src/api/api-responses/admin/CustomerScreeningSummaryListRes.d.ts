import CustomerSummary from "../../models/customer/CustomerSummary";

export default interface CustomerScreeningSummaryListRes {
    summary: Array<CustomerSummary>;    
}