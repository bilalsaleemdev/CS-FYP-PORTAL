import CustomerCrpIndividualProfile from "../../models/customer/CustomerCrpIndividualProfile";

export default interface CustomerCrpIndividualProfileRes {
    crp: CustomerCrpIndividualProfile;
}