import ScreeningcommentRes from "../../models/customer/ScreeningcommentRes";

export default interface ScreeningCommentsRes {
    comments: ScreeningcommentRes;
    user_message:any
    system_message:any
}