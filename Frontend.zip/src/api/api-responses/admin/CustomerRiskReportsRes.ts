import CustomerRiskReport from "../../models/customer/CustomerRiskReport";

export default interface CustomerRiskReporstRes {
        risk_reports: CustomerRiskReport;
}