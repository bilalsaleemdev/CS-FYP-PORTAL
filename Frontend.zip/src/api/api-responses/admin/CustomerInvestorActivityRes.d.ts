import CustomerInvestorActivity from "../../models/customer/CustomerInvestorActivity"

export default interface CustomerInvestorActivityRes {
    countryList: Array<CustomerInvestorActivity>;
}