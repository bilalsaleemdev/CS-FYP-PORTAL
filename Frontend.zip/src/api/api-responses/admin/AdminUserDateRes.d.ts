
export default interface AdminUserDateRes{
    user_roles: Array<string>,
    user_permissions: Array<string>
    menu: Array<string>
}