import CustomerProfileCorporate from "../../models/customer/CustomerProfileCorporate";

export default interface CustomerProfileCorporateRes {
    customer: CustomerProfileCorporate;
}