import Customer from "../../models/admin/Customer";

export default interface CustomerRes {
    customer: Customer;
}