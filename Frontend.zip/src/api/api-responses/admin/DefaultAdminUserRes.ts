export default interface DefaultAdminUserRes{
        admin_users: Array<number>,
    }