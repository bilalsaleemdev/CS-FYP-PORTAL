import CRPRolesMeta from "../../models/customer/CRPRolesMeta"

export default interface CRPRolesMetaRes {
    crp_roles_documents: Array<CRPRolesMeta>;
}
