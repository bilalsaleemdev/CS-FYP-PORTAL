
import ScreeningSummaryScreening from "../../models/customer/ScreeningSummaryScreening";

export default interface ScreeningSummaryRes {
    screening: ScreeningSummaryScreening
    count:number|null
}