import riskReportAssessmentRecordRes from "../../models/customer/riskReportRes";

export default interface RistAssessmentReportRecordRes {
    accessment_lists: riskReportAssessmentRecordRes;
    count:number
}