import AdminUser from "../../../api/models/admin/AdminUser";

export default interface AdminUserRes{
        admin_user: AdminUser,
    }