import OngoingDueDiligence from '../../models/admin/OngoingDueDiligence';

export default interface OngoingDueDiligenceRes {
    on_going_due_diligence: OngoingDueDiligence,
    count:number|null
}