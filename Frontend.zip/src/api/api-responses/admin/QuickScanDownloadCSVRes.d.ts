
export default interface QuickScanDownloadCSVRes {
    url: string|null,
}