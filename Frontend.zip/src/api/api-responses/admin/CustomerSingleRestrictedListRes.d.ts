import CustomerSingleRestrincedList from "../../models/customer/CustomerSingleRestrincedList"

export default interface CustomerSingleRestrictedListRes {
    restricted_list: CustomerSingleRestrincedList;
}