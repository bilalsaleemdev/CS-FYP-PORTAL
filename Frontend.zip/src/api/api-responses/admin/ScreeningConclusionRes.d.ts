import ScreeningConclusionDataRes from "../../models/customer/ScreeningcommentRes";

export default interface ScreeningConclusionRes {
    statuses: ScreeningConclusionDataRes;
}