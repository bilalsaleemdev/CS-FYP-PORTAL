import RestrictedListCustomer from "../../models/customer/RestrictedListCustomer";

export default interface RestrictedListCustomerRes {
    restricted_list_customer: RestrictedListCustomer;
}