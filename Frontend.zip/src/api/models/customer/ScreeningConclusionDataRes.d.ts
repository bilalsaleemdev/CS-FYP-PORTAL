
declare interface ScreeningcommentRes {
    id: number|null,    
    comment: string|null
}
export default ScreeningcommentRes;