
declare interface CustomerCrpRoleProfile {    
    crp_role_meta_id:string
    appointment_date:string
    signed_date: string;    
}
export default CustomerCrpRoleProfile;