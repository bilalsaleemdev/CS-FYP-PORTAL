
declare interface ScreeningWorldCheckRes {
categories: any
category: string|null
countryLinks: any
creationDate: string|null
events: any
gender: string|null
identityDocuments: any
markedStatus: string|null
matchStrength:  string|null
matchedNameType:  string|null
matchedTerm:  string|null
modificationDate:  string|null
primaryName: string|null
providerType: string|null
referenceId: string|null
resolution:  string|null
resultId:  string|null
resultReview: any
secondaryFieldResults: any
sources: any
submittedTerm: string|null
}
export default ScreeningWorldCheckRes;