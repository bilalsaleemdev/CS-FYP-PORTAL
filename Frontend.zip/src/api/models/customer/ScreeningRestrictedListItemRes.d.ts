declare interface ScreeningRestrictedListItemRes {

    comment: string | null
    countryCode: string | null
    dob: any
    id: number | null
    identityNumber: string | null
    name: string | null
    referenceNumber: string | null
    restrictedListId: number | null
    updatedAt: any
}
export default ScreeningRestrictedListItemRes;