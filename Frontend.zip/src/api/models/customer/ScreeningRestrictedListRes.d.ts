
import ScreeningRestrictedListItemRes from "../../models/customer/ScreeningRestrictedListItemRes";
declare interface ScreeningWorldCheckListRes {
    items: ScreeningRestrictedListItemRes
    }
    export default ScreeningWorldCheckListRes;