
declare interface CustomerInvestorActivity {
        id: number,
        name: string,
        key_name: string
    }
    export default CustomerInvestorActivity;