
declare interface ScreeningInternetResultRes {
  
    createdAt: Date,
isNlpFinished: boolean
link: string|null
markedStatus: string|null
matched: boolean
ner: string|null
nlpJson: string|null
qInternetSearch: number|null
referenceUpdateId: string|null
sentiment:string|null
summary: string|null
title: string|null
   
}
export default ScreeningInternetResultRes;