
declare interface riskReportRes {
    approveStatus: string | null
    computedRiskRating: string | null
    overRideRiskRating: string | null
}
export default riskReportRes;