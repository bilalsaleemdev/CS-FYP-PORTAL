
declare interface ScreeningSummaryScreening {
    customer_type: number|null
    fund_id: number|null
    id: number|null
    name: string|null
    organization_id: number|null
    screenConculion: string|null
    screenProcessed: boolean
    }
    export default ScreeningSummaryScreening;