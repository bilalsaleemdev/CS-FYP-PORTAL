
declare interface CRPRolesMeta {
    id: number,
    crp_role_meta_id: number,
    document_type_id: number,
    
}
export default CRPRolesMeta;