declare interface BusinessUnits {
        id: string;
        name: string;
    }
    export default BusinessUnits;