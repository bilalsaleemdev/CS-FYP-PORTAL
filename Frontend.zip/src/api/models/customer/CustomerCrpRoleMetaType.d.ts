
declare interface CustomerCrpRoleMetaType {
    id: string;
    key: string;
    name: string|null;
    crp_type: string;
    value_en: string;
}
export default CustomerCrpRoleMetaType;