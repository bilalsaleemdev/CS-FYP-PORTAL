export default interface RequiredDocumentType {
    id: number;
    type: string;
    name: string;
    parent_id?: string;
}
