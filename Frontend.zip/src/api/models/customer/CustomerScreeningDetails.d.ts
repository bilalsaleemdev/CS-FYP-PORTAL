
declare interface CustomerScreeningDetails {
    date_time: string;
    name: string;
    country: string;
    date_details: string;
    gender_key: string;
    risk: string;
    relevant_score: string;
    detail: string;
}
export default CustomerScreeningDetails;