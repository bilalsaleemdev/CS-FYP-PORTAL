
declare interface riskReportRes {
    category: string | null
    criteria: string | null
    id: number | null;
    score: number | null;
    percentage: number | null;
}
export default riskReportRes;