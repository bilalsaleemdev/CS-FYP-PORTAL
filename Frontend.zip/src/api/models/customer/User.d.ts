interface User {
    id: number;
    email: string,
    is_verified: boolean;
    user_type: string;
}
