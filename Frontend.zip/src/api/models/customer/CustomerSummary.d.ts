
declare interface CustomerSummary {
    status: string;
}
export default CustomerSummary;