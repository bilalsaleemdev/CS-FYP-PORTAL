
declare interface ScreeningcommentRes {
    status: string|null, 
}
export default ScreeningcommentRes;