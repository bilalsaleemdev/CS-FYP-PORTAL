
declare interface CustomerVerifyDocument {
    name: string;
    screening: string;
    face_compare: string;
    ocr: string;
    remarks: string;
}
export default CustomerVerifyDocument;