
declare interface CustomerScreeningResultArtemiscan {
    additional_information: string;
    alias: string;
    list: string;
    name: string; 
}
export default CustomerScreeningResultArtemiscan;