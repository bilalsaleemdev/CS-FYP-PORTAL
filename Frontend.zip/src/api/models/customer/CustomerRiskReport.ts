export default interface CustomerRiskReport {
        id: number;
        risk_percentage: number; 
    }