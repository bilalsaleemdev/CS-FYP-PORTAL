
declare interface CustomerPerodicReviewCustomer {
    id: number | null
    first_name: string | null
}
export default CustomerPerodicReviewCustomer;