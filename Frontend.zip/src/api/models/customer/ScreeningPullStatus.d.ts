
declare interface ScreeningPullStatus {
  
    found: boolean
    id: number|null
    overAllStatus: boolean
    }
    export default ScreeningPullStatus;