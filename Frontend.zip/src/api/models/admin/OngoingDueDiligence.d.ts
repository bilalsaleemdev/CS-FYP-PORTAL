export default interface OngoingDueDiligence {
    created_at: string | null;
    customerType: number | null;
    customerId: number | null;
    id: number | null;
    name: string | null;
    result: string | null;
    updated_at: string | null;
}