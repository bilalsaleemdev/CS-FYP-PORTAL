export default interface AdminUserRole {
    id: number,
    name: string,  
    assign:boolean  
}