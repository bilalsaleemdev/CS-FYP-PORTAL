export default interface IndividualOngoingDueDiligence{
    id: number;
    name: string;
    updated_at: string;
    result: string;
}