export default interface CorporateOngoingDueDiligence{
    id: number;
    name: string;
    updated_at: string;
    result: string;
}