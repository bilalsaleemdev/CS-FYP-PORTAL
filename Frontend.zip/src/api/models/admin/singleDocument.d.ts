
declare interface single_document {
    signed_url: any
}
export default single_document;