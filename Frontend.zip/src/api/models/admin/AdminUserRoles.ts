export default interface AdminUserRoles{
        id: number,
        name:string,
        assign:boolean,
        type_key:string,        
    }