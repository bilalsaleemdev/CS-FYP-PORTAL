export default interface Fund{
    id: number,
    named_id: string,
    description: string
}