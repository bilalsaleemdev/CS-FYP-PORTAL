export default interface AdminUserNotificationSummary {
        pending_cases :number,
        overdue_cases :number,
        periodic_review :number,
        expired_documents :number,
        total_tasks :number
    }
    