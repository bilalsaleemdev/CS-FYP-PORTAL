export default interface AdminUserNotificationPeriodicReview {    
        periodic_review :number,
        cases:Array<{}>
    }
    