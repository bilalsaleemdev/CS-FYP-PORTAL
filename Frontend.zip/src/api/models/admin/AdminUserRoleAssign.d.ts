
export default interface AdminUserRoleAssign {
        admin_user_id: number;
        role_id: number;  
        assign:string;  
           
}
