import Role from "./Role";

export default interface AdminUserProfile {
        name: string;
        email: string;        
}
