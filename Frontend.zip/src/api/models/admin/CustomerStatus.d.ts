export default interface CustomerStatus {
    key : string,
    value : number, 
    name : string
}