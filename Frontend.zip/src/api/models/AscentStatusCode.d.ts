export default interface AscentStatusCode {
    key?: string;
    value: number;
    name?: string;
}