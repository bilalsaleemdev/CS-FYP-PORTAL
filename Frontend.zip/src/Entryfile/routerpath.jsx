const publicPath = '/';

export const routeCodes = {
  HOME: publicPath,
  LOGIN: `${ publicPath }login`,
  REGISTER: `${ publicPath }register`,
};