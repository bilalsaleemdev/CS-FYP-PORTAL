export let Config = (function () {
        let API_URL = process.env.API_URL;
        return {
            API_URL
        };
    })();
    